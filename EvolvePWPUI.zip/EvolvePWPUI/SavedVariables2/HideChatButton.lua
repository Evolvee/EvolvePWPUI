
HCBxpos = nil
HCBypos = nil
HCBkeyable = false
HCBuseralpha = 0.25


BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 119.0222320556641,
		["x"] = 517.7112426757813,
	},
}

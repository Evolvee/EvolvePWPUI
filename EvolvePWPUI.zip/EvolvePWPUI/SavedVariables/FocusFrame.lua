
FocusFrameOptions = {
	["scale"] = 1,
	["lockpos"] = true,
	["hidewhendead"] = true,
}


CombatLogFixDB = {
	["report"] = true,
	["wait"] = false,
	["auto"] = true,
	["zone"] = true,
}


MoveAnything_CustomFrames = {
	{
		["name"] = "PartyMemberFrame1Debuff1",
		["helpfulName"] = "PartyMemberFrame1Debuff1",
	}, -- [1]
	{
		["name"] = "PartyMemberFrame2Debuff1",
		["helpfulName"] = "PartyMemberFrame2Debuff1",
	}, -- [2]
	{
		["name"] = "PartyMemberFrame3Debuff1",
		["helpfulName"] = "PartyMemberFrame3Debuff1",
	}, -- [3]
	{
		["name"] = "PartyMemberFrame4Debuff1",
		["helpfulName"] = "PartyMemberFrame4Debuff1",
	}, -- [4]
}
MoveAnything_CharacterSettings = {
	["default"] = {
		["MinimapCluster"] = {
			["originalLeft"] = 1173.333374023438,
			["scale"] = 1,
			["originalBottom"] = 576,
			["hidden"] = false,
			["y"] = 595.0001831054688,
			["x"] = 1186.333618164063,
			["movable"] = true,
			["name"] = "MinimapCluster",
			["originalScale"] = 1,
		},
	},
}
MoveAnything_UseCharacterSettings = false

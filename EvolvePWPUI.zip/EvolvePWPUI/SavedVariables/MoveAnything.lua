
MoveAnything_CustomFrames = {
}
MoveAnything_CharacterSettings = {
	["default"] = {
		["MinimapCluster"] = {
			["originalLeft"] = 1173.333374023438,
			["scale"] = 1,
			["originalBottom"] = 576,
			["hidden"] = false,
			["y"] = 595.0001831054688,
			["x"] = 1186.333618164063,
			["movable"] = true,
			["name"] = "MinimapCluster",
			["originalScale"] = 1,
		},
	},
}
MoveAnything_UseCharacterSettings = false


MoveAnything_CustomFrames = {
	{
		["name"] = "PartyMemberFrame1Debuff1",
		["helpfulName"] = "PartyMemberFrame1Debuff1",
	}, -- [1]
	{
		["name"] = "PartyMemberFrame2Debuff1",
		["helpfulName"] = "PartyMemberFrame2Debuff1",
	}, -- [2]
	{
		["name"] = "PartyMemberFrame3Debuff1",
		["helpfulName"] = "PartyMemberFrame3Debuff1",
	}, -- [3]
	{
		["name"] = "PartyMemberFrame4Debuff1",
		["helpfulName"] = "PartyMemberFrame4Debuff1",
	}, -- [4]
}
MoveAnything_CharacterSettings = {
	["default"] = {
		["PartyMemberFrame3Debuff1"] = {
			["originalLeft"] = 48.00000190734863,
			["scale"] = 1.066666666666667,
			["originalBottom"] = 5.999969482421875,
			["hidden"] = false,
			["y"] = -10.31263004755721,
			["x"] = 44.99999870080508,
			["movable"] = true,
			["name"] = "PartyMemberFrame3Debuff1",
			["originalScale"] = 1,
		},
		["PartyMemberFrame2Debuff1"] = {
			["originalLeft"] = 48.00000190734863,
			["scale"] = 1.066666666666667,
			["originalBottom"] = 6,
			["hidden"] = false,
			["y"] = -8.437474379317337,
			["x"] = 44.99999870080508,
			["movable"] = true,
			["name"] = "PartyMemberFrame2Debuff1",
			["originalScale"] = 1,
		},
		["MinimapCluster"] = {
			["originalLeft"] = 1173.333374023438,
			["scale"] = 1,
			["originalBottom"] = 576,
			["hidden"] = false,
			["y"] = 595.0001831054688,
			["x"] = 1186.333618164063,
			["movable"] = true,
			["name"] = "MinimapCluster",
			["originalScale"] = 1,
		},
		["PartyMemberFrame1Debuff1"] = {
			["originalLeft"] = 48.00000381469727,
			["scale"] = 1.066666666666667,
			["originalBottom"] = 6,
			["hidden"] = false,
			["y"] = -9.374971298968035,
			["x"] = 45.00000048894432,
			["movable"] = true,
			["name"] = "PartyMemberFrame1Debuff1",
			["originalScale"] = 1,
		},
		["PartyMemberFrame4Debuff1"] = {
			["originalLeft"] = 48.00000190734863,
			["scale"] = 1.066666666666667,
			["originalBottom"] = 6,
			["hidden"] = false,
			["y"] = -8.437541575172077,
			["x"] = 44.99999870080508,
			["movable"] = true,
			["name"] = "PartyMemberFrame4Debuff1",
			["originalScale"] = 1,
		},
	},
}
MoveAnything_UseCharacterSettings = false


IEFMinimapButton_OffsetX = 48.6251035403384
IEFMinimapButton_OffsetY = -64.78117428430377
ImprovedErrorSettings = {
	["gagNoise"] = true,
	["emptyButton"] = false,
	["alwaysShow"] = false,
	["stackTraceCapture"] = false,
	["blinkNotification"] = true,
	["displayCount"] = true,
	["displayOnError"] = false,
	["debugCapture"] = false,
	["XMLDebug"] = 0,
}

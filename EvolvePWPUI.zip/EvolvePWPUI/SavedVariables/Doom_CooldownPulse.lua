
DCP_Saved = {
	["fadeInTime"] = 0.3,
	["x"] = 512,
	["y"] = 384,
	["holdTime"] = 0,
	["iconSize"] = 75,
	["fadeOutTime"] = 0.7,
	["animScale"] = 1.5,
	["maxAlpha"] = 0.7,
}

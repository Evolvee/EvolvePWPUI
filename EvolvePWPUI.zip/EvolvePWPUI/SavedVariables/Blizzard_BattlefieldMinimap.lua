
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 271.0000305175781,
		["x"] = 1085.022338867188,
	},
}

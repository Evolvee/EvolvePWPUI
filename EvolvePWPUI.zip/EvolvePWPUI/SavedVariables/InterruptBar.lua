
InterruptBarDB = {
	["scale"] = 1.5,
	["Position"] = {
		["yOfs"] = -103.4873580932617,
		["xOfs"] = -89.59998321533203,
		["point"] = "TOPRIGHT",
		["relativePoint"] = "TOPRIGHT",
	},
	["hidden"] = true,
	["lock"] = false,
}

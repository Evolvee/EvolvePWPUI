
InterruptBarDB = {
	["scale"] = 1.5,
	["Position"] = {
		["yOfs"] = -103.4872894287109,
		["xOfs"] = -90.54801177978516,
		["point"] = "TOPRIGHT",
		["relativePoint"] = "TOPRIGHT",
	},
	["hidden"] = true,
	["lock"] = true,
}

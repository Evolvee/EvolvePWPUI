
BuffLibDB = {
	["sync"] = true,
}

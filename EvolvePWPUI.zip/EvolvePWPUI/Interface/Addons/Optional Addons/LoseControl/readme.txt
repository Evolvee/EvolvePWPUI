LoseControl backport to 2.4.3 by Schaka 
Based on LoseControl for 3.3.0 

Visit: https://github.com/Schaka/LoseControl
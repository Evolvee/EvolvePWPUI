﻿--[[
Korean
]]
local L = LibStub("AceLocale-3.0"):NewLocale("kgPanels","koKR")
if not L then return end

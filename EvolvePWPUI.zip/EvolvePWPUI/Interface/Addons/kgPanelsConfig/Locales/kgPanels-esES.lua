﻿--[[
Spanish
]]
local L = LibStub("AceLocale-3.0"):NewLocale("kgPanels","esES")
if not L then return end

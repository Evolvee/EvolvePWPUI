This addon contains 8 different fonts (and default WoW font) for damage. The file named "font.ttf" will replace your default WoW damage font.
To swap between the fonts just rename the font you want to have to "font.ttf", replacing the old one. 
All fonts have a backup in special folder.

Warning! If you use font #6 messages like "parry, miss, dodge" will be bugged. I don't recommend using it.

I don't think any of those fonts will work with other than EN language packs because it only has standart letters. Damage display will work always, but text messages ("PARRY") will be bugged.
This folder contains deep-dark recolored "Interface" files.
Move them inside Interface folder.

WARNING: This folder is designed for testing and is NOT completed yet. A lot of UI frames are missing. Use at your own risk.

This folder was made to resolve this issue: https://github.com/Evolvee/EvolvePWPUI/issues/25